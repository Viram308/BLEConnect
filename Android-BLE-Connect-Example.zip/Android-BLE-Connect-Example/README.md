# Android-BLE-Connect-Example
Simple example application that allows you to scan, and connect to a ble device on Android (M) API 23

I searched the web for hours on an up to date Android BLE connection tutorial or example to no avail. Even the BLE Android docs don't have up to date (M) API 23 code presented. Thus - here is a simple app that allows you to scan, connect, and disconnect from a ble a peripheral. Or as Androiders would call it, a server. 
